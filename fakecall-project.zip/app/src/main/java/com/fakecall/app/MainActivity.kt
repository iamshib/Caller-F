package com.fakecall.app

import android.Manifest
import android.app.Activity
import android.app.NotificationManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private val delays = intArrayOf(30, 60, 120, 180, 300, 600)
    private val labels = arrayOf("30 seconds", "1 minute", "2 minutes", "3 minutes", "5 minutes", "10 minutes")
    private lateinit var etName: EditText
    private lateinit var etNum: EditText
    private lateinit var spin: Spinner
    private lateinit var status: TextView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(32), dp(20), dp(32))
        }
        setContentView(ScrollView(this).apply { addView(col) })

        fun tv(t: String, sz: Float, c: Int, top: Int = 12) = TextView(this).apply {
            text = t; textSize = sz; setTextColor(c); setPadding(0, dp(top), 0, dp(4))
        }
        fun btn(t: String, f: () -> Unit) = Button(this).apply {
            text = t; isAllCaps = false; setOnClickListener { f() }
        }

        col.addView(tv("Fake Call", 28f, Color.BLACK, 0))
        col.addView(tv("Caller name", 13f, Color.GRAY))
        etName = EditText(this).apply { setText(Prefs.name(this@MainActivity)); setSingleLine() }
        col.addView(etName)
        col.addView(tv("Caller number", 13f, Color.GRAY))
        etNum = EditText(this).apply { setText(Prefs.num(this@MainActivity)); setSingleLine() }
        col.addView(etNum)
        col.addView(tv("Call arrives after", 13f, Color.GRAY))
        spin = Spinner(this).apply {
            adapter = ArrayAdapter(this@MainActivity, android.R.layout.simple_spinner_dropdown_item, labels)
            setSelection(maxOf(0, delays.indexOf(Prefs.delay(this@MainActivity))))
        }
        col.addView(spin)
        col.addView(Switch(this).apply {
            text = "Armed (long-press Volume Up)"
            isChecked = Prefs.armed(this@MainActivity)
            setPadding(0, dp(18), 0, dp(8))
            setOnCheckedChangeListener { _, on -> saveAll(); Prefs.setArmed(this@MainActivity, on) }
        })
        col.addView(tv("While armed, the Volume Up button only works as the trigger. Turn this off to use it normally.", 12f, Color.GRAY, 0))
        col.addView(btn("Save") { saveAll(); Toast.makeText(this, "Saved", Toast.LENGTH_SHORT).show() })
        col.addView(btn("Test call in 5 seconds") {
            saveAll()
            Toast.makeText(this, "Lock your screen now", Toast.LENGTH_SHORT).show()
            Handler(Looper.getMainLooper()).postDelayed({ Launcher.fire(this) }, 5000)
        })

        col.addView(tv("Setup (do all once)", 18f, Color.BLACK, 24))
        status = tv("", 13f, Color.DKGRAY, 4)
        col.addView(status)
        col.addView(btn("1. Enable accessibility service") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        })
        col.addView(btn("2. Allow display over other apps") {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
        })
        col.addView(btn("3. Allow notifications / full-screen") { askNotif() })
        col.addView(btn("4. Battery: no restrictions") {
            startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
        })
        col.addView(btn("5. App info (restricted settings, pop-ups)") {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
        })
    }

    private fun askNotif() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        } else if (Build.VERSION.SDK_INT >= 34) {
            val nm = getSystemService(NotificationManager::class.java)
            if (!nm.canUseFullScreenIntent()) {
                startActivity(Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:$packageName")))
            }
        }
    }

    private fun saveAll() {
        Prefs.save(
            this,
            etName.text.toString().ifBlank { "Unknown" },
            etNum.text.toString(),
            delays[spin.selectedItemPosition]
        )
    }

    override fun onPause() { super.onPause(); saveAll() }

    override fun onResume() {
        super.onResume()
        val en = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: ""
        status.text = "Accessibility: " + (if (en.contains(packageName)) "ON ✓" else "OFF ✗") +
            "\nDisplay over apps: " + (if (Settings.canDrawOverlays(this)) "ON ✓" else "OFF ✗")
    }
}
