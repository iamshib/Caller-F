package com.fakecall.app

import android.accessibilityservice.AccessibilityService
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class FakeCallService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var pending = false
    private val longPress = Runnable { trigger() }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    override fun onKeyEvent(ev: KeyEvent): Boolean {
        if (ev.keyCode != KeyEvent.KEYCODE_VOLUME_UP || !Prefs.armed(this)) return false
        if (ev.action == KeyEvent.ACTION_DOWN && ev.repeatCount == 0) h.postDelayed(longPress, 900)
        if (ev.action == KeyEvent.ACTION_UP) h.removeCallbacks(longPress)
        return true
    }

    private fun trigger() {
        if (pending) return
        pending = true
        getSystemService(Vibrator::class.java)
            .vibrate(VibrationEffect.createOneShot(80, VibrationEffect.DEFAULT_AMPLITUDE))
        val d = Prefs.delay(this) * 1000L
        val wl = getSystemService(PowerManager::class.java)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fakecall:wait")
        wl.acquire(d + 60_000L)
        h.postDelayed({
            pending = false
            Launcher.fire(this)
            if (wl.isHeld) wl.release()
        }, d)
    }
}
