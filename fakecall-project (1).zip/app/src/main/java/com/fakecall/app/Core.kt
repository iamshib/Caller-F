package com.fakecall.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("fc", Context.MODE_PRIVATE)
    fun name(c: Context) = sp(c).getString("n", "Dad") ?: "Dad"
    fun num(c: Context) = sp(c).getString("p", "+880 1712-345678") ?: ""
    fun delay(c: Context) = sp(c).getInt("d", 30)
    fun armed(c: Context) = sp(c).getBoolean("a", false)
    fun save(c: Context, n: String, p: String, d: Int) =
        sp(c).edit().putString("n", n).putString("p", p).putInt("d", d).apply()
    fun setArmed(c: Context, a: Boolean) = sp(c).edit().putBoolean("a", a).apply()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

object Launcher {
    fun fire(c: Context) {
        val i = Intent(c, CallActivity::class.java)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        val nm = c.getSystemService(NotificationManager::class.java)
        val ch = NotificationChannel("call", "Incoming call", NotificationManager.IMPORTANCE_HIGH)
        ch.setSound(null, null)
        ch.enableVibration(false)
        ch.lockscreenVisibility = Notification.VISIBILITY_PUBLIC
        nm.createNotificationChannel(ch)
        val pi = PendingIntent.getActivity(
            c, 0, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(c, "call")
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle(Prefs.name(c))
            .setContentText("Incoming call")
            .setCategory(Notification.CATEGORY_CALL)
            .setOngoing(true)
            .setContentIntent(pi)
            .setFullScreenIntent(pi, true)
            .build()
        nm.notify(1, n)
        try { c.startActivity(i) } catch (e: Exception) { }
    }

    fun clear(c: Context) {
        c.getSystemService(NotificationManager::class.java).cancel(1)
    }
}

class IconView(c: Context, private val type: Int) : View(c) {
    companion object {
        const val MIC = 0
        const val DIAL = 1
        const val SPK = 2
        const val ADD = 3
        const val PAUSE = 4
        const val REC = 5
        const val PHONE = 6
    }

    var tint: Int = Color.WHITE
        set(v) { field = v; invalidate() }
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val s = width / 24f
        cv.scale(s, s)
        p.color = tint
        p.style = Paint.Style.FILL
        p.strokeCap = Paint.Cap.ROUND
        p.strokeWidth = 2f
        when (type) {
            MIC -> {
                cv.drawRoundRect(9f, 2.5f, 15f, 14f, 3f, 3f, p)
                p.style = Paint.Style.STROKE
                cv.drawArc(6f, 6f, 18f, 18f, 0f, 180f, false, p)
                cv.drawLine(12f, 18f, 12f, 21.5f, p)
                cv.drawLine(8.5f, 21.5f, 15.5f, 21.5f, p)
            }
            DIAL -> {
                for (r in 0..3) for (k in 0..2) cv.drawCircle(6f + 6f * k, 4.5f + 5f * r, 1.7f, p)
            }
            SPK -> {
                val path = Path()
                path.moveTo(3.5f, 9f); path.lineTo(7.5f, 9f); path.lineTo(12.5f, 4.5f)
                path.lineTo(12.5f, 19.5f); path.lineTo(7.5f, 15f); path.lineTo(3.5f, 15f)
                path.close()
                cv.drawPath(path, p)
                p.style = Paint.Style.STROKE
                cv.drawArc(8.5f, 8f, 16.5f, 16f, -45f, 90f, false, p)
                cv.drawArc(4.5f, 4f, 20.5f, 20f, -45f, 90f, false, p)
            }
            ADD -> {
                p.strokeWidth = 2.4f
                cv.drawLine(12f, 5f, 12f, 19f, p)
                cv.drawLine(5f, 12f, 19f, 12f, p)
            }
            PAUSE -> {
                cv.drawRoundRect(6.5f, 4.5f, 10.5f, 19.5f, 1.2f, 1.2f, p)
                cv.drawRoundRect(13.5f, 4.5f, 17.5f, 19.5f, 1.2f, 1.2f, p)
            }
            REC -> {
                cv.drawCircle(12f, 12f, 4.5f, p)
                p.style = Paint.Style.STROKE
                cv.drawCircle(12f, 12f, 9f, p)
            }
            PHONE -> {
                p.style = Paint.Style.STROKE
                p.strokeWidth = 4.6f
                val path = Path()
                path.moveTo(3.5f, 15.5f)
                path.quadTo(12f, 6f, 20.5f, 15.5f)
                cv.drawPath(path, p)
            }
        }
    }
}

fun Context.circle(type: Int, sizeDp: Int, bg: Int, tint: Int = Color.WHITE, rot: Float = 0f): FrameLayout {
    val f = FrameLayout(this)
    f.background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(bg) }
    val ic = IconView(this, type)
    ic.tint = tint
    ic.rotation = rot
    val isz = dp(sizeDp * 45 / 100)
    f.addView(ic, FrameLayout.LayoutParams(isz, isz, Gravity.CENTER))
    return f
}
