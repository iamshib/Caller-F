package com.fakecall.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.Ringtone
import android.media.RingtoneManager
import android.media.ToneGenerator
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.GridLayout
import android.widget.LinearLayout
import android.widget.TextView
import java.util.Locale

class CallActivity : Activity() {
    private val BG = Color.parseColor("#17181C")
    private val RED = "#F2403A"
    private val GREEN = "#2DC66B"
    private val GREY = "#2E3036"
    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private val h = Handler(Looper.getMainLooper())
    private lateinit var root: FrameLayout
    private var ringtone: Ringtone? = null
    private var vib: Vibrator? = null
    private var tone: ToneGenerator? = null
    private var active = false
    private var ended = false
    private var secs = 0
    private var hold = false
    private var rec = false
    private var timerTv: TextView? = null
    private var tagTv: TextView? = null
    private var pad: View? = null
    private var typed: TextView? = null

    private val tick = object : Runnable {
        override fun run() {
            if (!hold) secs++
            refreshTimer()
            h.postDelayed(this, 1000)
        }
    }
    private val missed = Runnable { finishCall() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        setShowWhenLocked(true)
        setTurnScreenOn(true)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        window.statusBarColor = BG
        window.navigationBarColor = BG
        root = FrameLayout(this)
        root.setBackgroundColor(BG)
        setContentView(root)
        try { tone = ToneGenerator(AudioManager.STREAM_DTMF, 70) } catch (e: Exception) { }
        showIncoming()
        startRing()
        h.postDelayed(missed, 45000)
    }

    override fun onNewIntent(i: Intent?) { super.onNewIntent(i) }
    @Suppress("DEPRECATION")
    override fun onBackPressed() { }

    // ---------- helpers ----------
    private fun clr(s: String) = Color.parseColor(s)
    private fun lp(w: Int, h: Int, wt: Float = 0f) = LinearLayout.LayoutParams(w, h, wt)
    private fun column() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
    }
    private fun text(t: String, sz: Float, color: Int, top: Int) = TextView(this).apply {
        text = t; textSize = sz; setTextColor(color); gravity = Gravity.CENTER
        setPadding(0, dp(top), 0, 0)
    }
    private fun avatar(sz: Int) = TextView(this).apply {
        text = Prefs.name(this@CallActivity).trim().take(1).uppercase()
        textSize = sz * 0.4f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Color.parseColor("#5A6270")) }
        layoutParams = LinearLayout.LayoutParams(dp(sz), dp(sz))
    }
    private fun cell(label: String, v: View, size: Int): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER_HORIZONTAL
        addView(v, lp(dp(size), dp(size)))
        addView(text(label, 13f, clr("#C4C8CF"), 8))
    }
    private fun paint(v: FrameLayout, on: Boolean) {
        (v.background as GradientDrawable).setColor(if (on) Color.WHITE else clr(GREY))
        (v.getChildAt(0) as IconView).tint = if (on) Color.BLACK else Color.WHITE
    }

    // ---------- incoming ----------
    private fun showIncoming() {
        val col = column().apply { setPadding(0, dp(96), 0, dp(72)) }
        col.addView(avatar(112))
        col.addView(text(Prefs.name(this), 34f, Color.WHITE, 22))
        col.addView(text(Prefs.num(this), 16f, clr("#9AA0A6"), 6))
        col.addView(View(this), lp(0, 0, 1f))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dec = circle(IconView.PHONE, 72, clr(RED))
        dec.setOnClickListener { finishCall() }
        val acc = circle(IconView.PHONE, 72, clr(GREEN), Color.WHITE, -135f)
        acc.setOnClickListener { accept() }
        row.addView(cell("Decline", dec, 72), lp(0, WRAP, 1f))
        row.addView(cell("Accept", acc, 72), lp(0, WRAP, 1f))
        col.addView(row, lp(MATCH, WRAP))
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun startRing() {
        try {
            val uri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_RINGTONE)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ringtone = RingtoneManager.getRingtone(this, uri)
            ringtone?.audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_NOTIFICATION_RINGTONE)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()
            if (Build.VERSION.SDK_INT >= 28) ringtone?.isLooping = true
            ringtone?.play()
        } catch (e: Exception) { }
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (am.ringerMode != AudioManager.RINGER_MODE_SILENT) {
            vib = getSystemService(Vibrator::class.java)
            vib?.vibrate(VibrationEffect.createWaveform(longArrayOf(0, 800, 800), 0))
        }
    }

    private fun stopRing() {
        try { ringtone?.stop() } catch (e: Exception) { }
        vib?.cancel()
    }

    private fun accept() {
        if (active) return
        stopRing()
        h.removeCallbacks(missed)
        showActive()
        h.postDelayed(tick, 1000)
    }

    // ---------- active call ----------
    private fun showActive() {
        active = true
        root.removeAllViews()
        val col = column().apply { setPadding(0, dp(72), 0, dp(48)) }
        col.addView(avatar(84))
        col.addView(text(Prefs.name(this), 28f, Color.WHITE, 16))
        timerTv = text("00:00", 18f, clr("#B8BCC4"), 6)
        col.addView(timerTv)
        tagTv = text("", 14f, clr("#FF6B6B"), 4)
        col.addView(tagTv)

        val grid = GridLayout(this).apply { columnCount = 3 }
        fun add(v: View, label: String) {
            val glp = GridLayout.LayoutParams().apply {
                width = dp(104); height = WRAP; setMargins(0, dp(14), 0, dp(14))
            }
            grid.addView(cell(label, v, 64), glp)
        }
        fun toggle(type: Int, label: String, change: (Boolean) -> Unit) {
            var on = false
            val v = circle(type, 64, clr(GREY))
            v.setOnClickListener { on = !on; paint(v, on); change(on) }
            add(v, label)
        }
        fun press(type: Int, label: String, f: () -> Unit) {
            val v = circle(type, 64, clr(GREY))
            v.setOnClickListener { f() }
            add(v, label)
        }
        toggle(IconView.MIC, "Mute") { }
        press(IconView.DIAL, "Keypad") { pad?.visibility = View.VISIBLE }
        toggle(IconView.SPK, "Speaker") { }
        press(IconView.ADD, "Add call") { pad?.visibility = View.VISIBLE }
        toggle(IconView.PAUSE, "Hold") { hold = it; refreshTimer() }
        toggle(IconView.REC, "Record") { rec = it; refreshTimer() }
        col.addView(grid, lp(WRAP, WRAP).apply { topMargin = dp(36) })

        col.addView(View(this), lp(0, 0, 1f))
        val end = circle(IconView.PHONE, 72, clr(RED))
        end.setOnClickListener { endActive() }
        col.addView(end, lp(dp(72), dp(72)))
        root.addView(col, FrameLayout.LayoutParams(MATCH, MATCH))

        pad = buildPad()
        root.addView(pad, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun buildPad(): View {
        val col = column().apply {
            setBackgroundColor(BG)
            setPadding(0, dp(72), 0, dp(48))
            visibility = View.GONE
            isClickable = true
        }
        typed = text("", 32f, Color.WHITE, 0)
        col.addView(typed, lp(MATCH, dp(72)))
        val g = GridLayout(this).apply { columnCount = 3 }
        for (k in "123456789*0#") {
            val t = TextView(this).apply {
                text = k.toString()
                textSize = 28f
                setTextColor(Color.WHITE)
                gravity = Gravity.CENTER
                background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(clr(GREY)) }
                setOnClickListener {
                    typed?.append(k.toString())
                    val code = when (k) { '*' -> 10; '#' -> 11; else -> k - '0' }
                    tone?.startTone(code, 150)
                }
            }
            val glp = GridLayout.LayoutParams().apply {
                width = dp(76); height = dp(76); setMargins(dp(12), dp(8), dp(12), dp(8))
            }
            g.addView(t, glp)
        }
        col.addView(g, lp(WRAP, WRAP))
        col.addView(View(this), lp(0, 0, 1f))
        val hide = text("Hide", 18f, Color.WHITE, 0).apply {
            setPadding(dp(32), dp(14), dp(32), dp(14))
            setOnClickListener { col.visibility = View.GONE; typed?.text = "" }
        }
        col.addView(hide, lp(WRAP, WRAP))
        return col
    }

    private fun refreshTimer() {
        timerTv?.text = String.format(Locale.US, "%02d:%02d", secs / 60, secs % 60)
        tagTv?.text = when {
            hold -> "On hold"
            rec -> "● Recording"
            else -> ""
        }
    }

    private fun endActive() {
        if (ended) return
        h.removeCallbacks(tick)
        timerTv?.text = "Call ended"
        tagTv?.text = ""
        pad?.visibility = View.GONE
        h.postDelayed({ finishCall() }, 700)
    }

    private fun finishCall() {
        if (ended) return
        ended = true
        stopRing()
        h.removeCallbacksAndMessages(null)
        Launcher.clear(this)
        finish()
    }

    override fun onDestroy() {
        stopRing()
        h.removeCallbacksAndMessages(null)
        tone?.release()
        Launcher.clear(this)
        super.onDestroy()
    }
}
